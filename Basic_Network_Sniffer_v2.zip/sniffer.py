
from scapy.all import sniff, IP, TCP, UDP

def packet_callback(packet):
    if IP in packet:
        print("-" * 60)
        print(f"Source IP      : {packet[IP].src}")
        print(f"Destination IP : {packet[IP].dst}")
        print(f"Protocol       : {packet[IP].proto}")

        if TCP in packet:
            print("Protocol Name  : TCP")
            print(f"Source Port    : {packet[TCP].sport}")
            print(f"Destination Port: {packet[TCP].dport}")
        elif UDP in packet:
            print("Protocol Name  : UDP")
            print(f"Source Port    : {packet[UDP].sport}")
            print(f"Destination Port: {packet[UDP].dport}")

        print(f"Payload (first 40 bytes): {bytes(packet.payload)[:40]}")

def main():
    print("Basic Network Sniffer Started")
    print("Press CTRL + C to stop")
    sniff(prn=packet_callback, store=False)

if __name__ == "__main__":
    main()
