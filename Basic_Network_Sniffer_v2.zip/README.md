
# Basic Network Sniffer (Python)

## Objective
Capture and analyze live network packets to understand
how data flows across a network.

## Features
- Captures TCP & UDP packets
- Displays IP addresses and ports
- Shows packet payload (partial)
- Real-time packet analysis

## Requirements
- Python 3.x
- scapy library
- Administrator / Root access

## Install Scapy
pip install scapy

## Run Project
### Windows (CMD as Administrator)
python sniffer.py

### Linux
sudo python3 sniffer.py

## Ethical Use
Educational use only. Monitor only authorized networks.
